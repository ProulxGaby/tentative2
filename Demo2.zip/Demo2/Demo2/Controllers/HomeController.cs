﻿using Demo2.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo2.Controllers
{
    public class HomeController : Controller
    {
        private readonly CustomersContext context;

        public HomeController(CustomersContext _context)
        {
            context = _context;
        }
        public IActionResult Index()
        {
            return View(context.Customer);
        }
    }
}
